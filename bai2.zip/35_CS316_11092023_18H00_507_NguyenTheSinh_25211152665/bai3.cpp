#include<iostream>
#include<conio.h>
using namespace std;
int SLN1(int a[], int n);
void SLN2(int a[], int n, int &max);


int main(){
	int a[1000]={7,9,6,11,3}; int n=5; n--;
	int max;
	cout<<SLN1(a,n)<<"\n";
	SLN2(a,n, max);
	cout<<max;
	getch();
	return 0;
}

int SLN1(int a[], int n){
	int max=a[0];
	for(int i=0; i<n; i++){
		if (max<a[i]) max=a[i];
	}
	return max;
}

void SLN2(int a[], int n, int &max){
	int count=0;
	if (n<0){
		max=a[0];
		return;
	}
	SLN2(a, n-1, max);
	if (max<a[n]){
		max=a[n];
		count++;
	}
}





