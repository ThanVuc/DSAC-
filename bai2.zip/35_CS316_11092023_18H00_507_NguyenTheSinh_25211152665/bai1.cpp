#include<iostream>
#include<conio.h>
using namespace std;
void nhapmang(int a[], int &n);
void xuatmang(int a[], int n);


int main(){
	int a[1000]; int n;
	nhapmang(a, n);
	xuatmang(a, n);
	getch();
	return 0;
}

void nhapmang(int a[], int &n){
	cout<<"Nhap n: "; cin>>n;
	for(int i=0; i<n; i++){
		cout<<"a["<<i<<"]= ";
		cin>>a[i];
	}
}

void xuatmang(int a[], int n){
	cout<<"Mang xuat la: ";
	for(int i=0; i<n; i++){
		cout<<"a["<<i<<"]= "<<a[i]<<"\n";
	}
}

