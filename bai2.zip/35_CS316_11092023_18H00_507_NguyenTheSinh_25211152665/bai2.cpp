#include<iostream>
#include<conio.h>
using namespace std;
void nhapmang(int a[], int n);
void xuatmang(int a[], int n);


int main(){
	int a[1000]; int n;
	cout<<"Nhap n:"; cin>>n; n--;
	nhapmang(a, n);
	cout<<"Mang xuat:\n";
	xuatmang(a, n);
	getch();
	return 0;
}

void nhapmang(int a[], int n){
	if (n<0) return;
	nhapmang(a, n-1);
	cout<<"a["<<n<<"]= ";
	cin>>a[n];
}

void xuatmang(int a[], int n){
	if (n<0) return;
	xuatmang(a, n-1);
	cout<<"a["<<n<<"]= "<<a[n]<<"\n";
}



