#include<iostream>
#include<conio.h>
using namespace std;
int SLN1(int a[], int n);
int SLN2(int a[], int n);

int main(){
	int a[1000]={7,9,6,8,3}; int n=5;
	cout<<SLN2(a,n);
	getch();
	return 0;
}

int SLN2(int a[], int n){
	int max=a[0];
	int max1= a[0];
	for(int i=0; i<n; i++){
		if (a[i]>max) {
			max=a[i];
		}
		if (a[i]>max1 && a[i]<max){
			max1=a[i];
		}
	}
	return max1;
}