#include<iostream>
#include<conio.h>
using namespace std;
int TTT(int a[], int n, int k);
int TNP(int a[], int n, int k);
void TTT_dequy(int a[], int n, int k, int &vitri, int count);
int TNP_dequy(int a[], int d, int c, int k);

int main(){
	int a[1000]={1,2,3,4,5,7,8,10,12}; int n=8;
	int k, vitri;
	cout<<"nhap so can tim: "; cin>>k;
	int d=0, c=n-1, g=0;
	cout<<TNP_dequy(a,d,c,k);
	getch();
	return 0;
}




int TTT(int a[], int n, int k){
	cout<<"Nhap vi tri can Tim: "; cin>>k;
	for(int i=0; i<n; i++){
		if (a[i]==k) return i;
	}
	return -1;
}

void TTT_dequy(int a[], int n, int k, int &vitri, int count){
	if (n<0) return;
	TTT_dequy(a,n-1,k,vitri,0);
	if (a[n]==k && count==0){
		vitri=n;
		count++;
	}
}


int TNP(int a[], int n, int k){
	cout<<"Nhap tri can tim: "; cin>>k;
	int d=0, c=n-1, g;
	while (d<=c){
		g= (d+c)/2;
		if (a[d]==k) return d;
		if (a[c]==k) return c;
		if (a[g]==k) return g;
		if (a[g]>k){
			c=g-1;
			d++;
		}
		if (a[g]<k){
			d=g+1;
			c--;
		}
	}
	return -1;
}

int TNP_dequy(int a[], int d, int c, int k){
	int g= (d+c)/2;
	if (d>c) return -1;
	if (a[g]<k){
		TNP_dequy(a,g+1,c,k);
	}
	if (a[g]>k){
		TNP_dequy(a,d,g-1,k);
	}
	
	if (a[g]==k) return g;
}


