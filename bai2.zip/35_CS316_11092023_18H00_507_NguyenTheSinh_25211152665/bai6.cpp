#include<iostream>
#include<conio.h>
using namespace std;
void mangtang(int a[], int n, int &begin, int &end);

int main(){
	int a[1000]={1,2,3,4,5,2,4,5,6,7,8,9,10}; int n=13;
	int begin=0, end=0;
	mangtang(a,n,begin,end);
	cout<<begin<<" "<<end;
	getch();
	return 0;
}

void mangtang(int a[], int n, int &begin, int &end){
	int count=0, dis=0, b0=0, e0=0;
	for(int i=0; i<n-1; i++){
		if (a[i]>a[i+1]){
			count= 0;
			e0= i;
			if (count>dis){
				end= e0;
				begin= b0;
				dis= count;
				count= 0;
			}
			b0= i+1;
		} else{
			count++;
		}
	}
	if (count>dis){
		begin=b0;
		end=n-1;
	}
}
