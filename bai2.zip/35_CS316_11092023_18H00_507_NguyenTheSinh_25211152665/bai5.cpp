#include<iostream>
#include<conio.h>
using namespace std;
bool mangtang(int a[], int n);
bool manggiam(int a[], int n);

int main(){
	int a[1000]={5,4,3,2,1}; int n=5;
	if (mangtang(a,n)) cout<<"Mang Tang Dan\n";
	else cout<<"Mang Khong Tang Dan\n";
	
	if (manggiam(a,n)) cout<<"Mang Giam Gian\n";
	else cout<<"Mang Khong Giam Dan";
	getch();
	return 0;
}

bool mangtang(int a[], int n){
	for(int i=0; i<n-1; i++){
		if (a[i]>a[i+1]){
			return false;
		}
	}
	return true;
}

bool manggiam(int a[], int n){
	for(int i=0; i<n-1; i++){
		if (a[i]<a[i+1]){
			return false;
		}
	}
	return true;
}




